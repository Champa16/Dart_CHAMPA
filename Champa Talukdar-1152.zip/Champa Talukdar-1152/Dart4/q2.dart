void main() {
  Set<String> fruits = {"Apple", "Banana", "Mango", "Orange"};
  
  for (String fruit in fruits) {
    print(fruit);
  }
}
