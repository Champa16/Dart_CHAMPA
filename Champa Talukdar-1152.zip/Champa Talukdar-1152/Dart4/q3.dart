import 'dart:io';

void main() {
  List<double> expenses = [];
  double total = 0;

  print("Enter number of expenses:");
  int count = int.parse(stdin.readLineSync()!);

  for (int i = 0; i < count; i++) {
    print("Enter expense ${i + 1}:");
    double expense = double.parse(stdin.readLineSync()!);
    expenses.add(expense);
    total += expense;
  }

  print("Total expenses: \$${total.toStringAsFixed(2)}");
}
