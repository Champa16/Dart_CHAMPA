void main() {
  Map<String, String> contacts = {
    "John": "1234",
    "Paul": "56789",
    "Lisa": "9876",
    "Mark": "4321"
  };

  var keysWithLength4 = contacts.keys.where((key) => key.length == 4).toList();
  
  print("Keys with length 4: $keysWithLength4");
}
