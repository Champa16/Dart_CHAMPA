void main() {
  List<String> friends = ["Alice", "Bob", "Andrew", "Charlie", "Alex", "David", "Angela"];
  
  var namesWithA = friends.where((name) => name.startsWith('A')).toList();
  
  print("Names starting with 'A': $namesWithA");
}
