void main() {
  List<String> names = ["Alice", "Bob", "Charlie", "David"];
  print("Names: $names");
}
