void main() {
  Map<String, dynamic> person = {
    "name": "John",
    "address": "New York",
    "age": 25,
    "country": "USA"
  };

  person["country"] = "Canada";

  print("Updated Map: $person");
}
