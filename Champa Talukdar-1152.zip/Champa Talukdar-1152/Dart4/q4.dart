void main() {
  List<String> days = [];
  
  days.addAll(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]);
  
  print("Days of the week: $days");
}
