import 'dart:math';

double circleArea(double radius) {
  return pi * radius * radius;
}

void main() {
  print("Area of circle: ${circleArea(5)}");
}
