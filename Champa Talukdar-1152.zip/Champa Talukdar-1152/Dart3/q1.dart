void printName() {
  print("John Doe");
}

void main() {
  printName();
}
