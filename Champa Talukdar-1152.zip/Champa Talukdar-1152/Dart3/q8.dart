int add(int a, int b) {
  return a + b;
}

void main() {
  print("Sum: ${add(4, 6)}");
}
