import 'dart:math';

double power(int base, int exponent) {
  return pow(base, exponent).toDouble();
}

void main() {
  print("5^3 = ${power(5, 3)}");
}
