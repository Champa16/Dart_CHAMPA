void main() {
  int a = 5, b = 10;
  print("Before Swap: a = $a, b = $b");

  int temp = a;
  a = b;
  b = temp;

  print("After Swap: a = $a, b = $b");
}
