void main() {
  String text = "Hello World Dart";
  String newText = text.replaceAll(" ", "");
  print("Without spaces: $newText");
}
