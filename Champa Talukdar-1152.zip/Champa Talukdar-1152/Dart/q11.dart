void main() {
  double distance = 25, speed = 40;
  double time = (distance / speed) * 60; // Convert hours to minutes
  print("Time taken to reach office: ${time.toStringAsFixed(2)} minutes");
}
