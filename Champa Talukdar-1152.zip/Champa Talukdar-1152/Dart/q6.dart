void main() {
  int dividend = 17, divisor = 3;
  int quotient = dividend ~/ divisor;
  int remainder = dividend % divisor;
  
  print("Quotient: $quotient");
  print("Remainder: $remainder");
}
