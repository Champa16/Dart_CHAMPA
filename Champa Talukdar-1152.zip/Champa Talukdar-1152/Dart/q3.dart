void main() {
  double principal = 1000, time = 2, rate = 5;
  double interest = (principal * time * rate) / 100;
  print("Simple Interest: $interest");
}
