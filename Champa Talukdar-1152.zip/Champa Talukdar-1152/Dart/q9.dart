void main() {
  String numberString = "123";
  int number = int.parse(numberString);
  print("Converted Number: $number");
}
