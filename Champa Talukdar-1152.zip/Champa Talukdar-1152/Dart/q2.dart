void main() {
  const int number = 7;
  print(number);
}
