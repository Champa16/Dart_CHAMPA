import 'dart:io';

void main() {
  print("Enter a number:");
  int n = int.parse(stdin.readLineSync()!);

  int sum = (n * (n + 1)) ~/ 2;
  print("Sum of first $n natural numbers: $sum");
}
