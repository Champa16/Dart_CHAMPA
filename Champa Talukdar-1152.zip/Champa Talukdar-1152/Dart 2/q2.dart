import 'dart:io';

void main() {
  print("Enter a character:");
  String char = stdin.readLineSync()!.toLowerCase();

  if ("aeiou".contains(char)) {
    print("$char is a Vowel");
  } else {
    print("$char is a Consonant");
  }
}
