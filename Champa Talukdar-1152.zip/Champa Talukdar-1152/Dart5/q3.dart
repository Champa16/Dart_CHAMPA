import 'dart:io';

void main() {
  print("Current Directory: ${Directory.current.path}");
}
